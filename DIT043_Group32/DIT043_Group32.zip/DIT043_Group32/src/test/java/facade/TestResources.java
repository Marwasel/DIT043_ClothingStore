package facade;

public class TestResources {

    public static final String EOL = System.lineSeparator();
}
